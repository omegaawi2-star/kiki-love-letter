# A Little Reminder of How Special You Are

This is a small, mobile-friendly romantic webpage for KiKi.

## Preview
Open `index.html` in a modern browser. Keep the `assets` folder beside it.

## Publish it for a shareable link
A simple free option is GitHub Pages:
1. Sign in to GitHub and create a new **public** repository.
2. Upload `index.html` and the `assets` folder (including `sunset-memory.png`).
3. In the repository, open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. After GitHub Pages publishes it, copy the public website URL.

The QR code should be generated from that final public URL—not from a local file address. Once you have the URL, it can be turned into a high-resolution printable QR card.

## Notes
- The background is the romantic edited sunset image supplied for this project.
- The two usernames are kept visible.
- Floating hearts run in the background; opening the envelope creates a heart burst.
- The music is a gentle original synthesized chime loop and starts only when the visitor presses Play.
